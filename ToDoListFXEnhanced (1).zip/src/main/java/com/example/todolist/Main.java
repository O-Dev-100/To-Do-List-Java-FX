
package com.example.todolist;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {
        ListView<String> listView = new ListView<>();
        listView.getItems().addAll("Task 1", "Task 2", "Task 3");

        primaryStage.setScene(new Scene(listView, 400, 300));
        primaryStage.setTitle("Enhanced To-Do List");
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
            